
def simitarity(pref, string_to_check):
    count = 0
    for a, b in zip(pref, string_to_check):
        if a != b:
            return count
        count += 1
    return count

def sum_of_simitarity(simitarity_string):
    sum_of_simitarity = 0
    ten_string = len(simitarity_string)
    for i in range(1, len(simitarity_string)):
        sum_of_simitarity += simitarity(simitarity_string[i:], simitarity_string)
    sum_of_simitarity += ten_string * (ten_string + 1)//2

    return sum_of_simitarity

print(sum_of_simitarity('f aabd sdf sdf aab'))